import styled from 'styled-components';

export const Container = styled.div`
  display: grid;
  grid-template-columns: 1fr 2fr;
  align-items: baseline;

  button {
    border: 0;
    padding: 0.5rem;
    margin: 0.5rem;
  }

  input {
    padding: 0.3rem;
    margin: 0.1rem;
    border: 0;
    color: #000;
    background: rgb(240, 240, 240);
  }
`;

export const Form = styled.form`
  display: flex;
  flex-direction: column;

  border: 1px dashed;
  padding: 1rem;

  margin: 0 auto 0 0;
`;

export const Tabela = styled.table`
  border-spacing: 0;
  tr td {
    border: 1px solid #ddd;
    text-align: center;
  }
`;
