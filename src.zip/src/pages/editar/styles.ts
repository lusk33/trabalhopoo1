import styled from 'styled-components';

export const Container = styled.div`
  display: flex;
  flex-direction: column;
  align-items: baseline;

  button {
    border: 0;
    padding: 0.5rem;
    margin: 0.5rem;
  }

  input {
    padding: 0.3rem;
    margin: 0.1rem;
    border: 0;
    color: #000;
    background: rgb(240, 240, 240);
  }
`;

export const Form = styled.form`
  display: flex;
  flex-direction: column;

  margin: 0 auto 0 0;
`;
