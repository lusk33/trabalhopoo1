module.exports = {
  singleQuote: true,
  tabWidth: 2,
  trailingComma: 'all',
  arrowParens: 'avoid',
};
